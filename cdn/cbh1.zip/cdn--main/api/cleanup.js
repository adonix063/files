const GITHUB_REPO = process.env.GITHUB_REPO || "adonix063/files"
const GITHUB_BRANCH = process.env.GITHUB_BRANCH || "main"
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || "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"
const GITHUB_UPLOAD_PREFIX = (process.env.GITHUB_UPLOAD_PREFIX || "cdn").replace(/^\/+|\/+$/g, "")
const EXPIRE_GITHUB_REPO = process.env.EXPIRE_GITHUB_REPO || "adonix063/expire"
const EXPIRE_GITHUB_BRANCH = process.env.EXPIRE_GITHUB_BRANCH || "main"
const EXPIRE_GITHUB_TOKEN = process.env.EXPIRE_GITHUB_TOKEN || "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"
const EXPIRE_GITHUB_PATH = (process.env.EXPIRE_GITHUB_PATH || "expiry.json").replace(/^\/+/, "")

function githubContentsApiPath(repo, contentPath, branch) {
  const repoParts = repo.split("/")
  const encodedRepo = repoParts.map(p => encodeURIComponent(p)).join("/")
  const encodedPath = encodeURIComponent(contentPath).replace(/%2F/g, "/")
  const ref = branch ? `?ref=${encodeURIComponent(branch)}` : ""
  return `/repos/${encodedRepo}/contents/${encodedPath}${ref}`
}

async function githubRequest(method, apiPath, { body, token } = {}) {
  const headers = {
    Authorization: `Bearer ${token || GITHUB_TOKEN}`,
    "User-Agent": "files-adonix-cdn",
    "X-GitHub-Api-Version": "2022-11-28"
  }
  if (body !== undefined) headers["Content-Type"] = "application/json"

  const response = await fetch(`https://api.github.com${apiPath}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  })

  return response
}

async function readGithubJson(repo, branch, token, jsonPath) {
  const apiPath = githubContentsApiPath(repo, jsonPath, branch)
  const response = await githubRequest("GET", apiPath, { token })
  if (response.status === 404) return { data: null, sha: null }
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub read failed (${response.status}): ${details.slice(0, 240)}`)
  }

  const payload = await response.json()
  const content = Buffer.from(payload.content || "", "base64").toString("utf8")
  let data = null
  try {
    data = content ? JSON.parse(content) : null
  } catch {
    data = null
  }
  return { data, sha: payload.sha || null }
}

async function deleteFromGithub(repo, branch, token, filePath, message) {
  const apiPath = githubContentsApiPath(repo, filePath, branch)
  
  const getResponse = await githubRequest("GET", apiPath, { token })
  if (getResponse.status === 404) return true
  if (!(getResponse.status >= 200 && getResponse.status < 300)) {
    const details = await getResponse.text()
    console.log(`File ${filePath} not found or error: ${details.slice(0, 100)}`)
    return false
  }
  
  const payload = await getResponse.json()
  const sha = payload.sha
  
  const deleteResponse = await githubRequest("DELETE", apiPath, {
    body: {
      message,
      branch,
      sha
    },
    token
  })
  
  if (!(deleteResponse.status >= 200 && deleteResponse.status < 300)) {
    const details = await deleteResponse.text()
    console.error(`Delete failed for ${filePath}: ${details.slice(0, 100)}`)
    return false
  }
  
  console.log(`Deleted: ${filePath}`)
  return true
}

module.exports = async (req, res) => {
  // Verificar que es una petición de cron job o manual
  const isCron = req.headers['x-vercel-signature'] || req.query.cron === 'true'
  
  if (!isCron && req.method !== 'GET') {
    res.writeHead(403, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ error: "Forbidden" }))
    return
  }

  try {
    const { data, sha } = await readGithubJson(EXPIRE_GITHUB_REPO, EXPIRE_GITHUB_BRANCH, EXPIRE_GITHUB_TOKEN, EXPIRE_GITHUB_PATH)
    
    if (!data || !data.files) {
      res.writeHead(200, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ deleted: 0, message: "No files to check" }))
      return
    }

    const now = Date.now()
    const expiredFiles = []
    
    for (const [filename, fileData] of Object.entries(data.files)) {
      if (fileData.expiresAt && now > fileData.expiresAt) {
        expiredFiles.push(filename)
      }
    }

    if (expiredFiles.length === 0) {
      res.writeHead(200, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ deleted: 0, message: "No expired files" }))
      return
    }

    // Borrar archivos expirados (máximo 5 por ejecución para no sobrecargar)
    const toDelete = expiredFiles.slice(0, 5)
    let deletedCount = 0
    
    for (const filename of toDelete) {
      try {
        const deleted = await deleteFromGithub(
          GITHUB_REPO,
          GITHUB_BRANCH,
          GITHUB_TOKEN,
          `${GITHUB_UPLOAD_PREFIX}/${filename}`,
          `Delete expired file ${filename}`
        )
        
        if (deleted) {
          delete data.files[filename]
          deletedCount++
        }
      } catch (error) {
        console.error(`Error deleting ${filename}:`, error)
      }
    }

    // Actualizar expiry.json
    if (deletedCount > 0) {
      data.updatedAt = now
      const apiPath = githubContentsApiPath(EXPIRE_GITHUB_REPO, EXPIRE_GITHUB_PATH, EXPIRE_GITHUB_BRANCH)
      const body = {
        message: `Remove ${deletedCount} expired files`,
        branch: EXPIRE_GITHUB_BRANCH,
        content: Buffer.from(JSON.stringify(data, null, 2), "utf8").toString("base64")
      }
      if (sha) body.sha = sha
      
      await githubRequest("PUT", apiPath, { 
        body, 
        token: EXPIRE_GITHUB_TOKEN 
      })
    }

    res.writeHead(200, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ 
      deleted: deletedCount, 
      checked: Object.keys(data.files).length + deletedCount,
      expiredFound: expiredFiles.length,
      message: `Deleted ${deletedCount} expired files` 
    }))
    
  } catch (error) {
    console.error("Cleanup error:", error)
    res.writeHead(500, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ error: error.message }))
  }
}
