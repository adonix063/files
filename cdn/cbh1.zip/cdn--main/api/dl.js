const path = require("path")

const GITHUB_REPO = process.env.GITHUB_REPO || "adonix063/files"
const GITHUB_BRANCH = process.env.GITHUB_BRANCH || "main"
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || "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"
const GITHUB_UPLOAD_PREFIX = (process.env.GITHUB_UPLOAD_PREFIX || "cdn").replace(/^\/+|\/+$/g, "")
const EXPIRE_GITHUB_REPO = process.env.EXPIRE_GITHUB_REPO || "adonix063/expire"
const EXPIRE_GITHUB_BRANCH = process.env.EXPIRE_GITHUB_BRANCH || "main"
const EXPIRE_GITHUB_TOKEN = process.env.EXPIRE_GITHUB_TOKEN || "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"
const EXPIRE_GITHUB_PATH = (process.env.EXPIRE_GITHUB_PATH || "expiry.json").replace(/^\/+/, "")

const MIME_BY_EXT = {
  pdf: "application/pdf",
  txt: "text/plain",
  js: "text/javascript",
  html: "text/html",
  css: "text/css",
  json: "application/json",
  xml: "application/xml",
  csv: "text/csv",
  svg: "image/svg+xml",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  m4a: "audio/mp4",
  opus: "audio/ogg",
  ogg: "audio/ogg",
  mp4: "video/mp4",
  mkv: "video/x-matroska",
  webm: "video/webm",
  mov: "video/quicktime",
  avi: "video/x-msvideo",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
  ico: "image/x-icon",
  bmp: "image/bmp",
  tiff: "image/tiff",
  zip: "application/zip",
  rar: "application/x-rar-compressed",
  "7z": "application/x-7z-compressed",
  tar: "application/x-tar",
  gz: "application/gzip",
  apk: "application/vnd.android.package-archive",
  exe: "application/x-msdownload",
  msi: "application/x-msi",
  iso: "application/x-iso9660-image",
  dmg: "application/x-apple-diskimage",
  bin: "application/octet-stream",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
}

function githubContentsApiPath(repo, contentPath, branch) {
  const repoParts = repo.split("/")
  const encodedRepo = repoParts.map(p => encodeURIComponent(p)).join("/")
  const encodedPath = encodeURIComponent(contentPath).replace(/%2F/g, "/")
  const ref = branch ? `?ref=${encodeURIComponent(branch)}` : ""
  return `/repos/${encodedRepo}/contents/${encodedPath}${ref}`
}

async function githubRequest(method, apiPath, { body, accept, token } = {}) {
  const headers = {
    Authorization: `Bearer ${token || GITHUB_TOKEN}`,
    "User-Agent": "files-adonix-cdn",
    "X-GitHub-Api-Version": "2022-11-28"
  }
  if (accept) headers.Accept = accept
  if (body !== undefined) headers["Content-Type"] = "application/json"

  const response = await fetch(`https://api.github.com${apiPath}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  })

  return response
}

async function readGithubJson(repo, branch, token, jsonPath) {
  const apiPath = githubContentsApiPath(repo, jsonPath, branch)
  const response = await githubRequest("GET", apiPath, { token })
  if (response.status === 404) return { data: null, sha: null }
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub read failed (${response.status}): ${details.slice(0, 240)}`)
  }

  const payload = await response.json()
  const content = Buffer.from(payload.content || "", "base64").toString("utf8")
  let data = null
  try {
    data = content ? JSON.parse(content) : null
  } catch {
    data = null
  }
  return { data, sha: payload.sha || null }
}

// Expiración deshabilitada - los archivos duran para siempre

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization")

  if (req.method === "OPTIONS") {
    res.writeHead(204)
    res.end()
    return
  }

  try {
    const url = new URL(req.url, `https://${req.headers.host}`)
    let filename = url.searchParams.get("file")
    
    if (!filename) {
      const pathParts = url.pathname.split("/")
      filename = pathParts[pathParts.length - 1] || pathParts[pathParts.length - 2]
    }
    
    // Expiración deshabilitada - los archivos nunca expiran

    const storagePath = `${GITHUB_UPLOAD_PREFIX}/${filename}`
    const apiPath = githubContentsApiPath(GITHUB_REPO, storagePath, GITHUB_BRANCH)
    const githubResponse = await githubRequest("GET", apiPath, {
      accept: "application/vnd.github.raw"
    })

    if (!(githubResponse.status >= 200 && githubResponse.status < 300)) {
      res.writeHead(404, { "Content-Type": "text/plain" })
      res.end("Not found")
      return
    }

    const ext = path.extname(filename).replace(".", "").toLowerCase()
    const mimeType = MIME_BY_EXT[ext] || "application/octet-stream"

    res.setHeader("Cache-Control", "public, max-age=31536000, immutable")
    res.setHeader("Content-Type", mimeType)
    res.writeHead(200)

    const arrayBuffer = await githubResponse.arrayBuffer()
    res.end(Buffer.from(arrayBuffer))
  } catch (error) {
    console.error("Download error:", error)
    res.writeHead(502, { "Content-Type": "text/plain" })
    res.end("Upstream error")
  }
}
