module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.writeHead(200, { "Content-Type": "application/json" })
  res.end(JSON.stringify({ ok: true }))
}
