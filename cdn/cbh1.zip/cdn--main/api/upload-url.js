const crypto = require("crypto")
const path = require("path")
const { URL } = require("url")

const GITHUB_REPO = process.env.GITHUB_REPO || "adonix063/files"
const GITHUB_BRANCH = process.env.GITHUB_BRANCH || "main"
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || "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"
const GITHUB_UPLOAD_PREFIX = (process.env.GITHUB_UPLOAD_PREFIX || "cdn").replace(/^\/+|\/+$/g, "")
const EXPIRE_GITHUB_REPO = process.env.EXPIRE_GITHUB_REPO || "adonix063/expire"
const EXPIRE_GITHUB_BRANCH = process.env.EXPIRE_GITHUB_BRANCH || "main"
const EXPIRE_GITHUB_TOKEN = process.env.EXPIRE_GITHUB_TOKEN || "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"
const EXPIRE_GITHUB_PATH = (process.env.EXPIRE_GITHUB_PATH || "expiry.json").replace(/^\/+/, "")

const RANDOM_ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789"

const MIME_BY_EXT = {
  pdf: "application/pdf",
  txt: "text/plain",
  js: "text/javascript",
  html: "text/html",
  css: "text/css",
  json: "application/json",
  xml: "application/xml",
  csv: "text/csv",
  svg: "image/svg+xml",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  m4a: "audio/mp4",
  opus: "audio/ogg",
  ogg: "audio/ogg",
  mp4: "video/mp4",
  mkv: "video/x-matroska",
  webm: "video/webm",
  mov: "video/quicktime",
  avi: "video/x-msvideo",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
  ico: "image/x-icon",
  bmp: "image/bmp",
  tiff: "image/tiff",
  zip: "application/zip",
  rar: "application/x-rar-compressed",
  "7z": "application/x-7z-compressed",
  tar: "application/x-tar",
  gz: "application/gzip",
  apk: "application/vnd.android.package-archive",
  exe: "application/x-msdownload",
  msi: "application/x-msi",
  iso: "application/x-iso9660-image",
  dmg: "application/x-apple-diskimage",
  bin: "application/octet-stream",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
}

const EXPIRY_OPTIONS = {
  "1m": 1 * 60 * 1000,
  "3m": 3 * 60 * 1000,
  "5m": 5 * 60 * 1000,
  "8m": 8 * 60 * 1000,
  "10m": 10 * 60 * 1000,
  "1h": 60 * 60 * 1000,
  "1d": 24 * 60 * 60 * 1000,
  "1w": 7 * 24 * 60 * 60 * 1000,
  never: null
}

const EXT_BY_MIME = Object.entries(MIME_BY_EXT).reduce((acc, [ext, mime]) => {
  acc[mime] = ext
  return acc
}, {})

let metadata = { files: {}, totalUploads: 0 }

function randomSlug(length = 4) {
  const bytes = crypto.randomBytes(length)
  return Array.from(bytes, (byte) => RANDOM_ALPHABET[byte % RANDOM_ALPHABET.length]).join("")
}

function sanitizeFilename(name) {
  const base = name ? path.basename(name) : ""
  const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, "-")
  return cleaned || `file-${crypto.randomUUID()}`
}

function resolveExpiry(expiresIn) {
  const value = expiresIn && EXPIRY_OPTIONS[expiresIn] !== undefined ? expiresIn : "never"
  const duration = EXPIRY_OPTIONS[value]
  return duration ? Date.now() + duration : null
}

function githubContentsApiPath(repo, contentPath, branch) {
  const repoParts = repo.split("/")
  const encodedRepo = repoParts.map(p => encodeURIComponent(p)).join("/")
  const encodedPath = encodeURIComponent(contentPath).replace(/%2F/g, "/")
  const ref = branch ? `?ref=${encodeURIComponent(branch)}` : ""
  return `/repos/${encodedRepo}/contents/${encodedPath}${ref}`
}

async function githubRequest(method, apiPath, { body, accept, token } = {}) {
  const headers = {
    Authorization: `Bearer ${token || GITHUB_TOKEN}`,
    "User-Agent": "files-adonix-cdn",
    "X-GitHub-Api-Version": "2022-11-28"
  }
  if (accept) headers.Accept = accept
  if (body !== undefined) headers["Content-Type"] = "application/json"

  const response = await fetch(`https://api.github.com${apiPath}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  })

  return response
}

async function uploadToGithub(storedName, buffer, originalName) {
  const apiPath = githubContentsApiPath(GITHUB_REPO, `${GITHUB_UPLOAD_PREFIX}/${storedName}`)
  const response = await githubRequest("PUT", apiPath, {
    body: {
      message: `Upload ${storedName} (${originalName || "archivo"})`,
      branch: GITHUB_BRANCH,
      content: buffer.toString("base64")
    }
  })

  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub upload failed (${response.status}): ${details.slice(0, 240)}`)
  }
}

async function readGithubJson(repo, branch, token, jsonPath) {
  const apiPath = githubContentsApiPath(repo, jsonPath, branch)
  const response = await githubRequest("GET", apiPath, { token })
  if (response.status === 404) return { data: null, sha: null }
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub read failed (${response.status}): ${details.slice(0, 240)}`)
  }

  const payload = await response.json()
  const content = Buffer.from(payload.content || "", "base64").toString("utf8")
  let data = null
  try {
    data = content ? JSON.parse(content) : null
  } catch {
    data = null
  }
  return { data, sha: payload.sha || null }
}

async function writeGithubJson(repo, branch, token, jsonPath, data, message) {
  const current = await readGithubJson(repo, branch, token, jsonPath)
  const apiPath = githubContentsApiPath(repo, jsonPath)
  const body = {
    message,
    branch,
    content: Buffer.from(JSON.stringify(data, null, 2), "utf8").toString("base64")
  }
  if (current.sha) body.sha = current.sha

  const response = await githubRequest("PUT", apiPath, { body, token })
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub write failed (${response.status}): ${details.slice(0, 240)}`)
  }
}

function buildExpirySnapshot() {
  const files = {}
  for (const [storedName, entry] of Object.entries(metadata.files || {})) {
    files[storedName] = {
      expiresAt: entry && entry.expiresAt ? entry.expiresAt : null,
      uploadedAt: entry && entry.uploadedAt ? entry.uploadedAt : null
    }
  }
  return {
    updatedAt: Date.now(),
    totalUploads: metadata.totalUploads || 0,
    files
  }
}

async function loadExpirySnapshotFromGithub() {
  try {
    const { data } = await readGithubJson(EXPIRE_GITHUB_REPO, EXPIRE_GITHUB_BRANCH, EXPIRE_GITHUB_TOKEN, EXPIRE_GITHUB_PATH)
    if (data) {
      if (data.files && typeof data.files === "object") {
        for (const [storedName, fileData] of Object.entries(data.files)) {
          if (!metadata.files[storedName]) {
            metadata.files[storedName] = {
              originalName: storedName,
              mime: "application/octet-stream",
              detectedExt: path.extname(storedName).replace(".", "") || "bin"
            }
          }
          if (fileData && typeof fileData === "object") {
            if (fileData.expiresAt !== undefined) {
              metadata.files[storedName].expiresAt = fileData.expiresAt
            }
            if (fileData.uploadedAt !== undefined && !metadata.files[storedName].uploadedAt) {
              metadata.files[storedName].uploadedAt = fileData.uploadedAt
            }
          }
        }
      }
      if ((!metadata.totalUploads || metadata.totalUploads === 0) && Number.isInteger(data.totalUploads)) {
        metadata.totalUploads = data.totalUploads
      }
    }
  } catch (error) {
    console.error("Failed to load expiry snapshot", error)
  }
}

async function saveExpirySnapshotToGithub() {
  try {
    const snapshot = buildExpirySnapshot()
    await writeGithubJson(
      EXPIRE_GITHUB_REPO,
      EXPIRE_GITHUB_BRANCH,
      EXPIRE_GITHUB_TOKEN,
      EXPIRE_GITHUB_PATH,
      snapshot,
      `Update expiry snapshot (${Object.keys(snapshot.files || {}).length} files)`
    )
  } catch (error) {
    console.error("Failed to save expiry snapshot", error)
  }
}

async function storeFileBuffer(buffer, originalName, expiresAt, req) {
  const safeName = sanitizeFilename(originalName || "archivo")
  const extFromName = path.extname(safeName).replace(".", "").toLowerCase()
  const extension = extFromName || "bin"
  const finalMime = MIME_BY_EXT[extension] || "application/octet-stream"

  const storedName = `${randomSlug(4)}.${extension}`
  
  await uploadToGithub(storedName, buffer, originalName)

  metadata.files[storedName] = {
    originalName: originalName || safeName,
    uploadedAt: Date.now(),
    expiresAt,
    mime: finalMime,
    detectedExt: extension,
    storagePath: `${GITHUB_UPLOAD_PREFIX}/${storedName}`
  }
  metadata.totalUploads += 1

  await saveExpirySnapshotToGithub()

  const host = req.headers.host || "cdn-dr3u.vercel.app"
  const proto = req.headers["x-forwarded-proto"] || "https"

  return {
    originalName: originalName || safeName,
    storedName,
    size: buffer.length,
    detected: extension,
    mime: finalMime,
    url: `/dl/${storedName}`,
    publicUrl: `${proto}://${host}/dl/${storedName}`,
    expiresAt
  }
}

function parseMime(contentType) {
  if (!contentType) return null
  const raw = Array.isArray(contentType) ? contentType[0] : contentType
  const mime = String(raw).split(";")[0].trim().toLowerCase()
  return mime || null
}

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization")

  if (req.method === "OPTIONS") {
    res.writeHead(204)
    res.end()
    return
  }

  try {
    await loadExpirySnapshotFromGithub()

    let payload
    try {
      if (typeof req.body === 'object' && req.body !== null && !Buffer.isBuffer(req.body)) {
        payload = req.body
      } else if (Buffer.isBuffer(req.body)) {
        payload = JSON.parse(req.body.toString("utf8"))
      } else if (typeof req.body === 'string') {
        payload = JSON.parse(req.body)
      } else {
        throw new Error('Invalid body type')
      }
    } catch (e) {
      console.error('JSON parse error:', e, 'Body:', req.body)
      res.writeHead(400, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ error: "JSON inválido" }))
      return
    }

    const targetUrl = payload && payload.url
    if (!targetUrl) {
      res.writeHead(400, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ error: "Falta la URL a descargar" }))
      return
    }

    let parsed
    try {
      parsed = new URL(targetUrl)
    } catch {
      res.writeHead(400, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ error: "URL inválida" }))
      return
    }

    if (!["http:", "https:"].includes(parsed.protocol)) {
      res.writeHead(400, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ error: "Solo se permiten URLs HTTP/HTTPS" }))
      return
    }

    const expiresAt = resolveExpiry(payload.expiresIn)
    
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
      Accept: "*/*"
    }

    const response = await fetch(parsed, { headers, redirect: "follow" })

    if (!(response.status >= 200 && response.status < 300)) {
      res.writeHead(502, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ error: `No se pudo obtener el archivo (status ${response.status})` }))
      return
    }

    const arrayBuffer = await response.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    const contentType = response.headers.get("content-type") || ""
    const mime = parseMime(contentType)
    let filename = "archivo"
    if (mime && EXT_BY_MIME[mime]) {
      filename = `archivo.${EXT_BY_MIME[mime]}`
    } else {
      const pathname = parsed.pathname || ""
      const base = path.basename(pathname)
      if (base && base !== "/" && base !== "." && base !== "..") {
        filename = base
      }
    }

    const stored = await storeFileBuffer(buffer, filename, expiresAt, req)

    res.writeHead(201, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ files: [stored], source: "url" }))
  } catch (error) {
    console.error("Upload URL error:", error)
    res.writeHead(500, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ error: error.message || "Upload failed" }))
  }
}
