const EXPIRE_GITHUB_REPO = process.env.EXPIRE_GITHUB_REPO || "adonix063/expire"
const EXPIRE_GITHUB_BRANCH = process.env.EXPIRE_GITHUB_BRANCH || "main"
const EXPIRE_GITHUB_TOKEN = process.env.EXPIRE_GITHUB_TOKEN || "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"
const EXPIRE_GITHUB_PATH = (process.env.EXPIRE_GITHUB_PATH || "expiry.json").replace(/^\/+/, "")

function githubContentsApiPath(repo, contentPath, branch) {
  const repoParts = repo.split("/")
  const encodedRepo = repoParts.map(p => encodeURIComponent(p)).join("/")
  const encodedPath = encodeURIComponent(contentPath).replace(/%2F/g, "/")
  const ref = branch ? `?ref=${encodeURIComponent(branch)}` : ""
  return `/repos/${encodedRepo}/contents/${encodedPath}${ref}`
}

async function githubRequest(method, apiPath, { body, accept, token } = {}) {
  const headers = {
    Authorization: `Bearer ${token || EXPIRE_GITHUB_TOKEN}`,
    "User-Agent": "files-adonix-cdn",
    "X-GitHub-Api-Version": "2022-11-28"
  }
  if (accept) headers.Accept = accept
  if (body !== undefined) headers["Content-Type"] = "application/json"

  const response = await fetch(`https://api.github.com${apiPath}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  })

  return response
}

async function readGithubJson(repo, branch, token, jsonPath) {
  const apiPath = githubContentsApiPath(repo, jsonPath, branch)
  const response = await githubRequest("GET", apiPath, { token })
  if (response.status === 404) return { data: null, sha: null }
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub read failed (${response.status}): ${details.slice(0, 240)}`)
  }

  const payload = await response.json()
  const content = Buffer.from(payload.content || "", "base64").toString("utf8")
  let data = null
  try {
    data = content ? JSON.parse(content) : null
  } catch {
    data = null
  }
  return { data, sha: payload.sha || null }
}

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization")

  if (req.method === "OPTIONS") {
    res.writeHead(204)
    res.end()
    return
  }

  try {
    const { data } = await readGithubJson(EXPIRE_GITHUB_REPO, EXPIRE_GITHUB_BRANCH, EXPIRE_GITHUB_TOKEN, EXPIRE_GITHUB_PATH)
    const totalUploads = data && data.totalUploads ? data.totalUploads : 0
    
    res.writeHead(200, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ totalUploads }))
  } catch (error) {
    console.error("Stats error:", error)
    res.writeHead(200, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ totalUploads: 0 }))
  }
}
