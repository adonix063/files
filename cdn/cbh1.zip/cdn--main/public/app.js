const uploadContainer = document.getElementById('uploadContainer')
const fileInput = document.getElementById('fileInput')
const selectFilesButton = document.getElementById('selectFilesButton')
const remoteUrlInput = document.getElementById('remoteUrl')
const uploadFromUrlButton = document.getElementById('uploadFromUrl')
const progressContainer = document.getElementById('uploadProgress')
const progressFill = document.getElementById('progressFill')
const progressText = document.getElementById('progressText')
const resultContainer = document.getElementById('resultContainer')
const resultList = document.getElementById('resultList')
const history = document.getElementById('history')
const healthStatus = document.getElementById('healthStatus')
const totalUploads = document.getElementById('totalUploads')

const historyItems = []

// Función para actualizar los docs con el dominio real
function updateApiDocs() {
  const origin = window.location.origin
  
  // Update Snippets
  const uploadSnippet = `curl -X POST -H "Content-Type: application/json" -d '{"content":"BASE64","filename":"archivo.pdf"}' ${origin}/api/upload`
  const resultSnippet = `${origin}/dl/hg5.pdf`
  const jsonSnippet = `curl -X POST -H "Content-Type: application/json" -d "{\\"url\\":\\"https://sitio.com/foto.jpg\\",\\"expiresIn\\":\\"5m\\"}" ${origin}/api/upload-url`

  const codeUpload = document.getElementById('code-upload')
  const codeResult = document.getElementById('code-result')
  const codeJson = document.getElementById('code-json')

  if(codeUpload) codeUpload.textContent = uploadSnippet
  if(codeResult) codeResult.textContent = resultSnippet
  if(codeJson) codeJson.textContent = jsonSnippet

  // Update Copy Buttons data
  const btnUpload = document.querySelector('#block-upload .copy-snippet')
  const btnResult = document.querySelector('#block-result .copy-snippet')
  const btnJson = document.querySelector('#block-json .copy-snippet')

  if(btnUpload) btnUpload.dataset.copy = uploadSnippet
  if(btnResult) btnResult.dataset.copy = resultSnippet
  if(btnJson) btnJson.dataset.copy = jsonSnippet
}

function beginUploadProgress(labelBuilder) {
  progressContainer.style.display = 'block'
  resultContainer.style.display = 'none'
  progressFill.style.width = '0%'
  const buildLabel = typeof labelBuilder === 'function' ? labelBuilder : () => labelBuilder
  progressText.textContent = buildLabel(0)

  let progress = 0
  const interval = setInterval(() => {
    progress = Math.min(progress + Math.random() * 12, 90)
    progressFill.style.width = `${progress}%`
    progressText.textContent = buildLabel(Math.round(progress))
  }, 200)

  return {
    finishSuccess(files) {
      clearInterval(interval)
      progressFill.style.width = '100%'
      progressText.textContent = 'Completo'
      setTimeout(() => {
        progressContainer.style.display = 'none'
        resultContainer.style.display = 'block'
        renderResults(files)
        attachCopyHandlers()
      }, 600)
    },
    fail() {
      clearInterval(interval)
      progressContainer.style.display = 'none'
    },
  }
}

function resolvePublicUrl(file) {
  if (file.publicUrl) return file.publicUrl
  return `${window.location.origin}${file.url}`
}

function renderHistory() {
  history.innerHTML = ''
  if (historyItems.length === 0) {
    history.innerHTML = '<div class="table-item" style="display:block; text-align:center; color:#94a3b8;">Sin cargas en esta sesión.</div>'
    return
  }
  historyItems.forEach((item) => {
    const wrapper = document.createElement('div')
    wrapper.className = 'table-item'
    
    // Formatear extensión para mostrar si se cambió a mp3
    let displayType = item.detected
    if(item.name.endsWith('.mp3') && (item.detected === 'opus' || item.detected === 'm4a')) {
      displayType = 'MP3 (convertido)'
    }

    wrapper.innerHTML = `
      <strong>${item.name}</strong>
      <span>${displayType}</span>
      <span>${(item.size / 1024).toFixed(2)} KB</span>
      <span><a href="${item.publicUrl}" target="_blank">Abrir</a></span>
    `
    history.appendChild(wrapper)
  })
}

function addHistory(files) {
  files.forEach((file) => {
    historyItems.unshift({
      name: file.storedName,
      detected: file.detected,
      size: file.size,
      expiresAt: file.expiresAt,
      publicUrl: resolvePublicUrl(file),
    })
  })
  renderHistory()
}

function renderResults(files) {
  resultList.innerHTML = ''
  files.forEach((file) => {
    const url = resolvePublicUrl(file)
    const row = document.createElement('div')
    row.className = 'result-item'
    row.innerHTML = `
      <div class="result-url">${url}</div>
      <button class="copy-button" data-url="${url}">
        <i class="far fa-copy"></i>
      </button>
    `
    resultList.appendChild(row)
  })
}

function attachCopyHandlers() {
  resultList.querySelectorAll('.copy-button').forEach((button) => {
    button.addEventListener('click', async () => {
      const url = button.dataset.url
      try {
        await navigator.clipboard.writeText(url)
        button.classList.add('copied')
        const icon = button.querySelector('i')
        icon.className = 'fas fa-check'
        setTimeout(() => {
          button.classList.remove('copied')
          icon.className = 'far fa-copy'
        }, 2000)
      } catch {
        alert('No se pudo copiar la URL.')
      }
    })
  })
}

function attachSnippetCopyHandlers() {
  document.querySelectorAll('.copy-snippet').forEach((button) => {
    button.addEventListener('click', async () => {
      const value = button.dataset.copy
      if(!value) return
      try {
        await navigator.clipboard.writeText(value)
        button.classList.add('copied')
        const icon = button.querySelector('i')
        icon.className = 'fas fa-check'
        setTimeout(() => {
          button.classList.remove('copied')
          icon.className = 'far fa-copy'
        }, 2000)
      } catch {
        alert('No se pudo copiar el comando.')
      }
    })
  })
}

async function checkHealth() {
  try {
    const response = await fetch('/api/health')
    if (!response.ok) throw new Error('offline')
    healthStatus.textContent = 'Activo'
    healthStatus.style.color = '#10b981'
  } catch {
    healthStatus.textContent = 'Sin conexión'
    healthStatus.style.color = '#ef4444'
  }
}

async function loadStats() {
  try {
    const response = await fetch('/api/stats')
    if (!response.ok) throw new Error('stats')
    const data = await response.json()
    totalUploads.textContent = data.totalUploads ?? 0
  } catch {
    totalUploads.textContent = '—'
  }
}

function preventDefaults(event) {
  event.preventDefault()
  event.stopPropagation()
}

;['dragenter', 'dragover', 'dragleave', 'drop'].forEach((eventName) => {
  uploadContainer.addEventListener(eventName, preventDefaults, false)
  document.body.addEventListener(eventName, preventDefaults, false)
})

;['dragenter', 'dragover'].forEach((eventName) => {
  uploadContainer.addEventListener(eventName, () => uploadContainer.classList.add('dragover'), false)
})

;['dragleave', 'drop'].forEach((eventName) => {
  uploadContainer.addEventListener(eventName, () => uploadContainer.classList.remove('dragover'), false)
})

uploadContainer.addEventListener('drop', (event) => {
  const files = event.dataTransfer.files
  handleFiles(files)
})

selectFilesButton.addEventListener('click', () => {
  fileInput.click()
})

fileInput.addEventListener('change', (event) => {
  handleFiles(event.target.files)
})

uploadFromUrlButton.addEventListener('click', (event) => {
  event.preventDefault()
  handleRemoteUrlUpload()
})

async function handleFiles(fileList) {
  const files = Array.from(fileList)
  if (!files.length) return

  const progressTracker = beginUploadProgress((value) => `Subiendo ${files.length} archivo(s)... ${value}%`)

  try {
    for (const file of files) {
      console.log('Procesando archivo:', file.name, 'Size:', file.size)
      
      const reader = new FileReader()
      const base64 = await new Promise((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result
          const base64Data = result.split(',')[1]
          console.log('Base64 generado, length:', base64Data.length)
          resolve(base64Data)
        }
        reader.onerror = (e) => {
          console.error('FileReader error:', e)
          reject(e)
        }
        reader.readAsDataURL(file)
      })

      console.log('Enviando a /api/upload')
      const response = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: base64,
          filename: file.name
        })
      })

      console.log('Respuesta status:', response.status)
      const data = await response.json()
      console.log('Respuesta data:', data)

      if (!response.ok) {
        throw new Error(data.error || 'Error al subir')
      }

      progressTracker.finishSuccess(data.files)
      addHistory(data.files)
      await loadStats()
    }
  } catch (error) {
    console.error('Error en handleFiles:', error)
    progressTracker.fail()
    alert(`Error al subir el archivo: ${error.message}`)
  } finally {
    fileInput.value = ''
  }
}

async function handleRemoteUrlUpload() {
  const url = remoteUrlInput.value.trim()
  if (!url) {
    alert('Ingresa una URL válida para subir.')
    return
  }

  const progressTracker = beginUploadProgress((value) => `Descargando desde URL... ${value}%`)

  try {
    const payload = JSON.stringify({ url })
    const endpoint = '/api/upload-url'

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
    })

    const contentType = response.headers.get('content-type') || ''
    const data = contentType.includes('application/json') ? await response.json() : { error: await response.text() }

    if (!response.ok) {
      throw new Error(data?.error || `Error HTTP ${response.status}`)
    }

    progressTracker.finishSuccess(data.files)
    addHistory(data.files)
    await loadStats()
    remoteUrlInput.value = ''
  } catch (error) {
    progressTracker.fail()
    alert(`Error al subir la URL: ${error.message}`)
  }
}

// Inicialización
renderHistory()
checkHealth()
loadStats()
updateApiDocs()
attachSnippetCopyHandlers()
