const http = require("http")
const os = require("os")
const fs = require("fs")
const fsp = require("fs/promises")
const path = require("path")
const crypto = require("crypto")
const { URL } = require("url")
const { Agent, fetch } = require("undici")

const HOST = "0.0.0.0"
const PORT = process.env.PORT || 3000
const PUBLIC_DIR = path.join(__dirname, "public")
const UPLOAD_DIR = path.join(__dirname, "uploads")
const META_PATH = path.join(UPLOAD_DIR, "metadata.json")
const GITHUB_REPO = process.env.GITHUB_REPO || "adonix063/files"
const GITHUB_BRANCH = process.env.GITHUB_BRANCH || "main"
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || "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"
const GITHUB_UPLOAD_PREFIX = (process.env.GITHUB_UPLOAD_PREFIX || "cdn").replace(/^\/+|\/+$/g, "")
const EXPIRE_GITHUB_REPO = process.env.EXPIRE_GITHUB_REPO || "adonix063/expire"
const EXPIRE_GITHUB_BRANCH = process.env.EXPIRE_GITHUB_BRANCH || "main"
const EXPIRE_GITHUB_TOKEN = "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"
const EXPIRE_GITHUB_PATH = (process.env.EXPIRE_GITHUB_PATH || "expiry.json").replace(/^\/+/, "")

const MAX_BODY_SIZE = 1024 * 1024 * 1024
const SOURCE_IPV6 = process.env.SOURCE_IPV6 || "2604:a00:50:1d2:216:3eff:fe30:ebdb"

const MIME_BY_EXT = {
  pdf: "application/pdf",
  txt: "text/plain",
  js: "text/javascript",
  html: "text/html",
  css: "text/css",
  json: "application/json",
  xml: "application/xml",
  csv: "text/csv",
  svg: "image/svg+xml",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  m4a: "audio/mp4",
  opus: "audio/ogg", 
  ogg: "audio/ogg",
  mp4: "video/mp4",
  mkv: "video/x-matroska",
  webm: "video/webm",
  mov: "video/quicktime",
  avi: "video/x-msvideo",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
  ico: "image/x-icon",
  bmp: "image/bmp",
  tiff: "image/tiff",
  zip: "application/zip",
  rar: "application/x-rar-compressed",
  "7z": "application/x-7z-compressed",
  tar: "application/x-tar",
  gz: "application/gzip",
  apk: "application/vnd.android.package-archive",
  exe: "application/x-msdownload",
  msi: "application/x-msi",
  iso: "application/x-iso9660-image",
  dmg: "application/x-apple-diskimage",
  bin: "application/octet-stream",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
}

const EXT_BY_MIME = Object.entries(MIME_BY_EXT).reduce((acc, [ext, mime]) => {
  acc[mime] = ext
  return acc
}, {})

const EXPIRY_OPTIONS = {
  "1m": 1 * 60 * 1000,
  "3m": 3 * 60 * 1000,
  "5m": 5 * 60 * 1000,
  "8m": 8 * 60 * 1000,
  "10m": 10 * 60 * 1000,
  "1h": 60 * 60 * 1000,
  "1d": 24 * 60 * 60 * 1000,
  "1w": 7 * 24 * 60 * 60 * 1000,
  never: null
}

const RANDOM_ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789"
const ZIP_CONTAINER_EXTS = new Set(["apk", "docx", "xlsx", "pptx", "jar", "odt", "ods", "odp"])

let metadata = { files: {}, totalUploads: 0 }

function setCors(req, res) {
  const origin = req.headers.origin || "*"
  res.setHeader("Access-Control-Allow-Origin", origin === "null" ? "*" : origin)
  res.setHeader("Vary", "Origin")
  res.setHeader("Access-Control-Allow-Credentials", "true")
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
  res.setHeader("Access-Control-Max-Age", "86400")
}

function respondJson(req, res, status, payload) {
  setCors(req, res)
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" })
  res.end(JSON.stringify(payload))
}

function respondText(req, res, status, text) {
  setCors(req, res)
  res.writeHead(status, { "Content-Type": "text/plain; charset=utf-8" })
  res.end(text)
}

function safeLower(s) {
  return String(s || "").trim().toLowerCase()
}

function parseMime(contentType) {
  if (!contentType) return null
  const raw = Array.isArray(contentType) ? contentType[0] : contentType
  const mime = String(raw).split(";")[0].trim().toLowerCase()
  return mime || null
}

function guessTypeFromHeader(contentType) {
  const mime = parseMime(contentType)
  if (!mime) return { ext: null, mime: null }
  const ext = EXT_BY_MIME[mime] || null
  return { ext, mime: ext ? MIME_BY_EXT[ext] : mime }
}

function u32be(buf, off) {
  if (!buf || buf.length < off + 4) return null
  return buf.readUInt32BE(off)
}

function isIsoBmff(buffer) {
  if (!buffer || buffer.length < 16) return false
  const size = u32be(buffer, 0)
  const type = buffer.slice(4, 8).toString("ascii")
  if (type !== "ftyp") return false
  if (!size || size < 8) return true
  return true
}

function readFtypBrands(buffer) {
  try {
    if (!isIsoBmff(buffer)) return { major: null, compatibles: [] }
    const major = buffer.slice(8, 12).toString("ascii")
    const size = u32be(buffer, 0) || 0
    const max = Math.min(buffer.length, size > 0 ? size : 64)
    const compatibles = []
    for (let i = 16; i + 4 <= max; i += 4) {
      compatibles.push(buffer.slice(i, i + 4).toString("ascii"))
    }
    return { major, compatibles }
  } catch {
    return { major: null, compatibles: [] }
  }
}

function looksLikeText(buffer) {
  const sample = buffer.slice(0, Math.min(buffer.length, 8192)).toString("utf8")
  if (!sample) return false
  if (/[\x00-\x08\x0E-\x1F]/.test(sample)) return false
  return true
}

function guessTypeFromBuffer(buffer, hintedMime) {
  if (!buffer || buffer.length < 4) return { ext: null, mime: null, confidence: 0 }

  // Firmas comunes
  if (buffer.slice(0, 5).toString() === "%PDF-") return { ext: "pdf", mime: MIME_BY_EXT.pdf, confidence: 0.99 }
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return { ext: "jpg", mime: MIME_BY_EXT.jpg, confidence: 0.99 }
  if (buffer.length >= 8 && buffer.slice(0, 8).toString("hex") === "89504e470d0a1a0a") return { ext: "png", mime: MIME_BY_EXT.png, confidence: 0.99 }
  if (buffer.slice(0, 3).toString() === "GIF") return { ext: "gif", mime: MIME_BY_EXT.gif, confidence: 0.99 }
  if (buffer.length >= 12 && buffer.slice(8, 12).toString("ascii") === "WEBP") return { ext: "webp", mime: MIME_BY_EXT.webp, confidence: 0.98 }
  if (buffer.slice(0, 4).toString() === "<svg") return { ext: "svg", mime: MIME_BY_EXT.svg, confidence: 0.9 }
  
  if (buffer.slice(0, 3).toString() === "ID3") return { ext: "mp3", mime: MIME_BY_EXT.mp3, confidence: 0.98 }
  if (buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0) return { ext: "mp3", mime: MIME_BY_EXT.mp3, confidence: 0.95 }

  // NUEVO: Detección de contenedores WebM / Matroska (EBML)
  // yt-dlp opus suele venir en contenedor WebM.
  // Firma EBML: 1A 45 DF A3
  if (buffer.slice(0, 4).toString("hex") === "1a45dfa3") {
     return { ext: "webm", mime: MIME_BY_EXT.webm, confidence: 0.95 }
  }

  // NUEVO: Detección de contenedor Ogg (Opus/Vorbis raw)
  // Firma: OggS
  if (buffer.slice(0, 4).toString("ascii") === "OggS") {
    return { ext: "opus", mime: MIME_BY_EXT.opus, confidence: 0.95 }
  }

  if (buffer.slice(0, 2).toString("hex") === "504b") return { ext: "zip", mime: MIME_BY_EXT.zip, confidence: 0.95 }
  if (buffer.slice(0, 2).toString("hex") === "1f8b") return { ext: "gz", mime: MIME_BY_EXT.gz, confidence: 0.95 }
  if (buffer.slice(0, 6).toString("ascii") === "Rar!") return { ext: "rar", mime: MIME_BY_EXT.rar, confidence: 0.95 }
  if (buffer.slice(0, 6).toString("hex") === "377abcaf271c") return { ext: "7z", mime: MIME_BY_EXT["7z"], confidence: 0.95 }
  if (buffer.slice(0, 2).toString("hex") === "4d5a") return { ext: "exe", mime: MIME_BY_EXT.exe, confidence: 0.8 }

  const hinted = parseMime(hintedMime)
  if (isIsoBmff(buffer)) {
    const { major, compatibles } = readFtypBrands(buffer)
    const all = [major, ...compatibles].filter(Boolean).map((x) => x.trim())
    const allLower = all.map((x) => x.toLowerCase())

    const m4aBrands = new Set(["m4a", "m4b", "m4p"])
    const m4vBrands = new Set(["m4v"])
    const majorLower = safeLower(major).replace(/\s+/g, "")

    if (m4aBrands.has(majorLower)) return { ext: "m4a", mime: MIME_BY_EXT.m4a, confidence: 0.95 }
    if (m4vBrands.has(majorLower)) return { ext: "mp4", mime: MIME_BY_EXT.mp4, confidence: 0.9 }

    if (hinted === "audio/mp4") return { ext: "m4a", mime: MIME_BY_EXT.m4a, confidence: 0.92 }
    if (hinted === "video/mp4") return { ext: "mp4", mime: MIME_BY_EXT.mp4, confidence: 0.92 }

    if (allLower.some((b) => b.replace(/\s+/g, "") === "m4a")) return { ext: "m4a", mime: MIME_BY_EXT.m4a, confidence: 0.9 }

    if (hinted && hinted.startsWith("audio/")) return { ext: "m4a", mime: MIME_BY_EXT.m4a, confidence: 0.75 }
    return { ext: "mp4", mime: MIME_BY_EXT.mp4, confidence: 0.7 }
  }

  if (looksLikeText(buffer)) {
    const textSample = buffer.slice(0, Math.min(buffer.length, 16384)).toString("utf8")
    if (/\b(function|const|let|var|import|export|=>)\b/.test(textSample)) return { ext: "js", mime: MIME_BY_EXT.js, confidence: 0.7 }
    if (textSample.trim().startsWith("<html") || textSample.trim().startsWith("<!DOCTYPE html")) return { ext: "html", mime: MIME_BY_EXT.html, confidence: 0.8 }
    if (textSample.trim().startsWith("{") || textSample.trim().startsWith("[")) return { ext: "json", mime: MIME_BY_EXT.json, confidence: 0.6 }
    return { ext: "txt", mime: MIME_BY_EXT.txt, confidence: 0.65 }
  }

  if (hinted && EXT_BY_MIME[hinted]) {
    const ext = EXT_BY_MIME[hinted]
    return { ext, mime: MIME_BY_EXT[ext] || hinted, confidence: 0.55 }
  }

  return { ext: null, mime: null, confidence: 0 }
}

function sanitizeFilename(name) {
  const base = name ? path.basename(name) : ""
  const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, "-")
  return cleaned || `file-${crypto.randomUUID()}`
}

function randomSlug(length = 4) {
  const bytes = crypto.randomBytes(length)
  return Array.from(bytes, (byte) => RANDOM_ALPHABET[byte % RANDOM_ALPHABET.length]).join("")
}

function resolveFileExtension(filename, detectedExt, detectedConfidence) {
  const extFromName = path.extname(filename || "").replace(".", "").toLowerCase()
  const weakNameExts = new Set(["bin", "dat", "file", "tmp", "download"])
  let finalExt = null

  if (!extFromName) {
    finalExt = detectedExt || "bin"
  } else if (detectedExt && detectedExt !== extFromName) {
    if (detectedExt === "zip" && ZIP_CONTAINER_EXTS.has(extFromName)) {
      finalExt = extFromName
    } else if (weakNameExts.has(extFromName)) {
      finalExt = detectedExt
    } else if ((detectedConfidence || 0) >= 0.85) {
      finalExt = detectedExt
    } else {
      finalExt = extFromName
    }
  } else {
    finalExt = extFromName || detectedExt || "bin"
  }

  return finalExt
}

function resolveExpiry(expiresIn) {
  const value = expiresIn && EXPIRY_OPTIONS[expiresIn] !== undefined ? expiresIn : "never"
  const duration = EXPIRY_OPTIONS[value]
  return duration ? Date.now() + duration : null
}

function getHostIp() {
  const interfaces = os.networkInterfaces()
  for (const entries of Object.values(interfaces)) {
    for (const entry of entries || []) {
      if (entry.family === "IPv4" && !entry.internal) return entry.address
    }
  }
  return "127.0.0.1"
}

function isGoogleVideo(targetUrl) {
  try {
    const u = new URL(targetUrl)
    return u.hostname.endsWith("googlevideo.com") && u.pathname.includes("/videoplayback")
  } catch {
    return false
  }
}

function buildRemoteHeaders(targetUrl) {
  const hostIp = getHostIp()

  if (isGoogleVideo(targetUrl)) {
    return {
      "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
      Accept: "*/*",
      "Accept-Language": "en-us,en;q=0.5",
      "Accept-Encoding": "identity",
      Referer: "https://www.youtube.com/",
      Origin: "https://www.youtube.com",
      Range: "bytes=0-",
      Connection: "keep-alive"
    }
  }

  const parsed = new URL(targetUrl)
  return {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-us,en;q=0.5",
    "Sec-Fetch-Mode": "navigate",
    "Accept-Encoding": "gzip, deflate, br",
    Referer: `${parsed.protocol}//${parsed.host}/`,
    "X-Forwarded-For": hostIp,
    "X-Real-IP": hostIp
  }
}

function parseContentDisposition(value) {
  const result = {}
  if (!value) return result

  const parts = String(value).split(";")
  for (const part of parts) {
    const p = part.trim()
    if (!p) continue
    const eq = p.indexOf("=")
    if (eq === -1) {
      result[p.toLowerCase()] = true
      continue
    }
    const key = p.slice(0, eq).trim().toLowerCase()
    const raw = p.slice(eq + 1).trim()
    const val = raw.replace(/^"|"$/g, "")
    result[key] = val
  }

  if (!result.filename && result["filename*"]) {
    const v = result["filename*"]
    const m = v.match(/^(?:utf-8''|UTF-8'')(.+)$/)
    if (m && m[1]) {
      try {
        result.filename = decodeURIComponent(m[1])
      } catch {
        result.filename = m[1]
      }
    }
  }

  return result
}

function isJsonRequest(req) {
  const ct = req.headers["content-type"] || ""
  const value = Array.isArray(ct) ? ct[0] : ct
  return String(value).toLowerCase().includes("application/json")
}

function publicUrl(req, filePath) {
  const protoHeader = req.headers["x-forwarded-proto"]
  const proto = Array.isArray(protoHeader) ? protoHeader[0] : protoHeader
  const scheme = proto || "http"
  return `${scheme}://${req.headers.host}${filePath}`
}

function isGithubStorageEnabled() {
  return Boolean(GITHUB_TOKEN && GITHUB_REPO)
}

function githubUploadPath(storedName) {
  return `${GITHUB_UPLOAD_PREFIX}/${storedName}`
}

function isGithubExpiryEnabled() {
  return Boolean(EXPIRE_GITHUB_TOKEN && EXPIRE_GITHUB_REPO)
}

function githubContentsApiPath(repo, contentPath, branch) {
  const repoParts = repo.split("/")
  const encodedRepo = repoParts.map(p => encodeURIComponent(p)).join("/")
  const encodedPath = encodeURIComponent(contentPath).replace(/%2F/g, "/")
  const ref = branch ? `?ref=${encodeURIComponent(branch)}` : ""
  return `/repos/${encodedRepo}/contents/${encodedPath}${ref}`
}

async function githubRequest(method, apiPath, { body, accept, token } = {}) {
  const headers = {
    Authorization: `Bearer ${token || GITHUB_TOKEN}`,
    "User-Agent": "files-adonix-cdn",
    "X-GitHub-Api-Version": "2022-11-28"
  }
  if (accept) headers.Accept = accept
  if (body !== undefined) headers["Content-Type"] = "application/json"

  const response = await fetch(`https://api.github.com${apiPath}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  })

  return response
}

async function uploadToGithub(storedName, buffer, originalName) {
  const apiPath = githubContentsApiPath(GITHUB_REPO, githubUploadPath(storedName))
  const response = await githubRequest("PUT", apiPath, {
    body: {
      message: `Upload ${storedName} (${originalName || "archivo"})`,
      branch: GITHUB_BRANCH,
      content: buffer.toString("base64")
    }
  })

  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub upload failed (${response.status}): ${details.slice(0, 240)}`)
  }
}

async function streamGithubFile(storagePath, res) {
  const apiPath = githubContentsApiPath(GITHUB_REPO, storagePath, GITHUB_BRANCH)
  const response = await githubRequest("GET", apiPath, {
    accept: "application/vnd.github.raw"
  })

  return response
}

async function readGithubJson(repo, branch, token, jsonPath) {
  const apiPath = githubContentsApiPath(repo, jsonPath, branch)
  const response = await githubRequest("GET", apiPath, { token })
  if (response.status === 404) return { data: null, sha: null }
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub read failed (${response.status}): ${details.slice(0, 240)}`)
  }

  const payload = await response.json()
  const content = Buffer.from(payload.content || "", "base64").toString("utf8")
  let data = null
  try {
    data = content ? JSON.parse(content) : null
  } catch {
    data = null
  }
  return { data, sha: payload.sha || null }
}

async function writeGithubJson(repo, branch, token, jsonPath, data, message) {
  const current = await readGithubJson(repo, branch, token, jsonPath)
  const apiPath = githubContentsApiPath(repo, jsonPath)
  const body = {
    message,
    branch,
    content: Buffer.from(JSON.stringify(data, null, 2), "utf8").toString("base64")
  }
  if (current.sha) body.sha = current.sha

  const response = await githubRequest("PUT", apiPath, { body, token })
  if (!(response.status >= 200 && response.status < 300)) {
    const details = await response.text()
    throw new Error(`GitHub write failed (${response.status}): ${details.slice(0, 240)}`)
  }
}

function buildExpirySnapshot() {
  const files = {}
  for (const [storedName, entry] of Object.entries(metadata.files || {})) {
    files[storedName] = {
      expiresAt: entry && entry.expiresAt ? entry.expiresAt : null,
      uploadedAt: entry && entry.uploadedAt ? entry.uploadedAt : null
    }
  }
  return {
    updatedAt: Date.now(),
    totalUploads: metadata.totalUploads || 0,
    files
  }
}

function mergeExpirySnapshot(snapshot) {
  if (!snapshot || !snapshot.files || typeof snapshot.files !== "object") return
  for (const [storedName, data] of Object.entries(snapshot.files)) {
    if (!metadata.files[storedName]) metadata.files[storedName] = { originalName: storedName, mime: "application/octet-stream", detectedExt: path.extname(storedName).replace(".", "") || "bin" }
    if (data && Object.prototype.hasOwnProperty.call(data, "expiresAt")) {
      metadata.files[storedName].expiresAt = data.expiresAt
    }
    if (data && Object.prototype.hasOwnProperty.call(data, "uploadedAt") && !metadata.files[storedName].uploadedAt) {
      metadata.files[storedName].uploadedAt = data.uploadedAt
    }
  }

  if ((!metadata.totalUploads || metadata.totalUploads === 0) && Number.isInteger(snapshot.totalUploads)) {
    metadata.totalUploads = snapshot.totalUploads
  }
}

async function loadExpirySnapshotFromGithub() {
  if (!isGithubExpiryEnabled()) return
  try {
    const { data } = await readGithubJson(EXPIRE_GITHUB_REPO, EXPIRE_GITHUB_BRANCH, EXPIRE_GITHUB_TOKEN, EXPIRE_GITHUB_PATH)
    if (data) mergeExpirySnapshot(data)
  } catch (error) {
    console.error("Failed to load expiry snapshot", error)
  }
}

async function saveExpirySnapshotToGithub() {
  if (!isGithubExpiryEnabled()) return
  try {
    const snapshot = buildExpirySnapshot()
    await writeGithubJson(
      EXPIRE_GITHUB_REPO,
      EXPIRE_GITHUB_BRANCH,
      EXPIRE_GITHUB_TOKEN,
      EXPIRE_GITHUB_PATH,
      snapshot,
      `Update expiry snapshot (${Object.keys(snapshot.files || {}).length} files)`
    )
  } catch (error) {
    console.error("Failed to save expiry snapshot", error)
  }
}

async function storeFileBuffer(buffer, originalName, expiresAt, req, contentType) {
  const safeName = sanitizeFilename(originalName || "archivo")
  const headerGuess = guessTypeFromHeader(contentType)
  const detected = guessTypeFromBuffer(buffer, headerGuess.mime)

  const extension = resolveFileExtension(
    safeName,
    detected.ext || headerGuess.ext,
    detected.confidence
  )

  const finalMime = MIME_BY_EXT[extension] || detected.mime || headerGuess.mime || "application/octet-stream"
  
  const storedName = `${randomSlug(4)}.${extension}`
  const filePath = path.join(UPLOAD_DIR, storedName)
  const storagePath = githubUploadPath(storedName)

  if (isGithubStorageEnabled()) {
    await uploadToGithub(storedName, buffer, originalName)
  } else {
    await fsp.writeFile(filePath, buffer)
  }

  let finalSize = buffer.length
  if (!isGithubStorageEnabled()) {
    try {
      const stat = await fsp.stat(filePath)
      finalSize = stat.size
    } catch {}
  }

  metadata.files[storedName] = {
    originalName: originalName || safeName,
    uploadedAt: Date.now(),
    expiresAt,
    mime: finalMime,
    detectedExt: extension,
    storagePath: isGithubStorageEnabled() ? storagePath : null
  }
  metadata.totalUploads += 1

  return {
    originalName: originalName || safeName,
    storedName,
    size: finalSize,
    detected: extension,
    mime: finalMime,
    url: `/dl/${storedName}`,
    publicUrl: publicUrl(req, `/dl/${storedName}`),
    expiresAt
  }
}

function serveStatic(req, res, pathname) {
  let filePath = path.join(PUBLIC_DIR, pathname === "/" ? "index.html" : pathname)
  if (!filePath.startsWith(PUBLIC_DIR)) {
    respondText(req, res, 403, "Forbidden")
    return
  }

  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      respondText(req, res, 404, "Not found")
      return
    }
    const ext = path.extname(filePath).replace(".", "").toLowerCase()
    const mimeType = MIME_BY_EXT[ext] || "application/octet-stream"

    setCors(req, res)
    res.writeHead(200, { "Content-Type": mimeType })
    fs.createReadStream(filePath).pipe(res)
  })
}

function parseMultipart(buffer, boundary) {
  const parts = []
  const boundaryBuffer = Buffer.from(`--${boundary}`)
  let start = buffer.indexOf(boundaryBuffer)

  while (start !== -1) {
    start += boundaryBuffer.length
    const end = buffer.indexOf(boundaryBuffer, start)
    if (end === -1) break

    const part = buffer.slice(start, end)
    const headerEnd = part.indexOf("\r\n\r\n")
    if (headerEnd === -1) {
      start = end
      continue
    }

    const headerRaw = part.slice(0, headerEnd).toString()
    const body = part.slice(headerEnd + 4, part.length - 2)

    const headers = {}
    headerRaw.split("\r\n").forEach((line) => {
      const idx = line.indexOf(":")
      if (idx === -1) return
      const key = line.slice(0, idx).trim().toLowerCase()
      const val = line.slice(idx + 1).trim()
      if (!key) return
      headers[key] = val
    })

    parts.push({ headers, body })
    start = end
  }

  return parts
}

async function handleMultipartUpload(req, res, buffer) {
  const contentType = req.headers["content-type"] || ""
  const boundaryMatch = String(contentType).match(/boundary=(.+)$/i)
  if (!boundaryMatch) {
    respondJson(req, res, 400, { error: "Missing multipart boundary" })
    return
  }

  const boundary = boundaryMatch[1]
  const parts = parseMultipart(buffer, boundary)

  const files = []
  const fields = {}
  const fileParts = []

  for (const part of parts) {
    const disposition = part.headers["content-disposition"] || ""
    if (!disposition.includes("form-data")) continue
    const info = parseContentDisposition(disposition)
    const filenameRaw = info.filename || ""
    if (!filenameRaw) {
      if (info.name) fields[info.name] = part.body.toString("utf8").trim()
      continue
    }
    fileParts.push({ filenameRaw, body: part.body, contentType: part.headers["content-type"] || null })
  }

  const expiresAt = resolveExpiry(fields.expiresIn)

  for (const part of fileParts) {
    const stored = await storeFileBuffer(part.body, part.filenameRaw, expiresAt, req, part.contentType)
    files.push(stored)
  }

  if (files.length) await saveMetadata()
  if (!files.length) {
    respondJson(req, res, 400, { error: "No files found in multipart payload" })
    return
  }

  respondJson(req, res, 201, { files })
}

function normalizeHeadersObject(obj) {
  if (!obj || typeof obj !== "object") return null
  const out = {}
  for (const [k, v] of Object.entries(obj)) {
    if (!k) continue
    if (v === null || v === undefined) continue
    out[String(k)] = String(v)
  }
  return out
}

function pickRemoteFilename(parsedUrl, responseHeaders) {
  const cd = responseHeaders.get("content-disposition")
  const info = parseContentDisposition(cd)
  if (info && info.filename) return info.filename

  const p = String(parsedUrl.pathname || "").trim()
  const base = path.basename(p)
  if (base && base !== "/" && base !== "." && base !== "..") return base

  const ct = parseMime(responseHeaders.get("content-type"))
  if (ct && EXT_BY_MIME[ct]) return `archivo.${EXT_BY_MIME[ct]}`
  return "archivo-remoto"
}

async function handleRemoteUpload(req, res, body) {
  let payload
  try {
    payload = JSON.parse(body.toString("utf8"))
  } catch {
    respondJson(req, res, 400, { error: "JSON inválido" })
    return
  }

  const targetUrl = payload && payload.url
  if (!targetUrl) {
    respondJson(req, res, 400, { error: "Falta la URL a descargar" })
    return
  }

  let parsed
  try {
    parsed = new URL(targetUrl)
  } catch {
    respondJson(req, res, 400, { error: "URL inválida" })
    return
  }

  if (!["http:", "https:"].includes(parsed.protocol)) {
    respondJson(req, res, 400, { error: "Solo se permiten URLs HTTP/HTTPS" })
    return
  }

  const expiresAt = resolveExpiry(payload.expiresIn)
  const baseHeaders = buildRemoteHeaders(targetUrl)
  const extraHeaders = normalizeHeadersObject(payload.headers)
  const headers = extraHeaders ? { ...baseHeaders, ...extraHeaders } : baseHeaders

  let dispatcher = undefined
  if (SOURCE_IPV6 && isGoogleVideo(targetUrl)) {
    dispatcher = new Agent({ connect: { localAddress: SOURCE_IPV6 } })
  }

  try {
    const response = await fetch(parsed, { headers, redirect: "follow", dispatcher })

    if (!(response.status >= 200 && response.status < 300)) {
      respondJson(req, res, 502, { error: `No se pudo obtener el archivo (status ${response.status})` })
      return
    }

    const contentLength = Number(response.headers.get("content-length"))
    if (contentLength && contentLength > MAX_BODY_SIZE) {
      respondJson(req, res, 413, { error: "El archivo remoto es demasiado grande" })
      return
    }

    const arrayBuffer = await response.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    if (buffer.length > MAX_BODY_SIZE) {
      respondJson(req, res, 413, { error: "El archivo remoto es demasiado grande" })
      return
    }

    const derivedName = pickRemoteFilename(parsed, response.headers)
    const stored = await storeFileBuffer(buffer, derivedName, expiresAt, req, response.headers.get("content-type"))
    await saveMetadata()

    respondJson(req, res, 201, { files: [stored], source: "url" })
  } catch (error) {
    console.error("Error al descargar archivo remoto", error)
    respondJson(req, res, 502, { error: "No se pudo descargar el archivo remoto" })
  }
}

async function collectRequestBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let total = 0

    req.on("data", (chunk) => {
      total += chunk.length
      if (total > MAX_BODY_SIZE) {
        reject(new Error("Payload too large"))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })

    req.on("end", () => resolve(Buffer.concat(chunks)))
    req.on("error", reject)
  })
}

async function ensureUploadDir() {
  await fsp.mkdir(UPLOAD_DIR, { recursive: true })
}

async function loadMetadata() {
  try {
    const raw = await fsp.readFile(META_PATH, "utf8")
    const parsed = JSON.parse(raw)

    if (parsed && parsed.files && typeof parsed.files === "object") {
      metadata = {
        files: parsed.files,
        totalUploads: Number.isInteger(parsed.totalUploads) ? parsed.totalUploads : Object.keys(parsed.files).length
      }
    } else if (parsed && typeof parsed === "object") {
      metadata = { files: parsed, totalUploads: Object.keys(parsed).length }
    } else {
      metadata = { files: {}, totalUploads: 0 }
    }
  } catch (error) {
    if (error && error.code !== "ENOENT") console.error("Failed to load metadata", error)
    metadata = { files: {}, totalUploads: 0 }
  }

  await loadExpirySnapshotFromGithub()
}

async function saveMetadata() {
  await fsp.writeFile(META_PATH, JSON.stringify(metadata, null, 2))
  await saveExpirySnapshotToGithub()
}

const server = http.createServer(async (req, res) => {
  setCors(req, res)

  const url = new URL(req.url, `http://${req.headers.host}`)

  if (req.method === "OPTIONS") {
    res.writeHead(204)
    res.end()
    return
  }

  if (
    req.method === "GET" &&
    (url.pathname === "/" ||
      url.pathname.startsWith("/assets") ||
      url.pathname.endsWith(".css") ||
      url.pathname.endsWith(".js"))
  ) {
    serveStatic(req, res, url.pathname)
    return
  }

  if (req.method === "GET" && (url.pathname.startsWith("/dl/") || url.pathname.startsWith("/fl/"))) {
    const filename = path.basename(url.pathname)
    const filePath = path.join(UPLOAD_DIR, filename)
    const entry = metadata.files[filename]

    if (entry && entry.expiresAt && Date.now() > entry.expiresAt) {
      respondText(req, res, 410, "Expired")
      return
    }

    const ext = path.extname(filePath).replace(".", "").toLowerCase()
    const mimeType = MIME_BY_EXT[ext] || (entry && entry.mime) || "application/octet-stream"

    if (isGithubStorageEnabled()) {
      try {
        const storagePath = (entry && entry.storagePath) || githubUploadPath(filename)
        const githubResponse = await streamGithubFile(storagePath, res)
        if (!(githubResponse.status >= 200 && githubResponse.status < 300)) {
          respondText(req, res, 404, "Not found")
          return
        }

        setCors(req, res)
        res.setHeader("Cache-Control", "public, max-age=31536000, immutable")
        res.writeHead(200, { "Content-Type": mimeType })

        const arrayBuffer = await githubResponse.arrayBuffer()
        res.end(Buffer.from(arrayBuffer))
      } catch (error) {
        console.error("GitHub proxy download failed", error)
        respondText(req, res, 502, "Upstream error")
      }
      return
    }

    fs.stat(filePath, (err, stat) => {
      if (err || !stat.isFile()) {
        respondText(req, res, 404, "Not found")
        return
      }

      setCors(req, res)
      res.setHeader("Cache-Control", "public, max-age=31536000, immutable")
      res.writeHead(200, { "Content-Type": mimeType })
      fs.createReadStream(filePath).pipe(res)
    })

    return
  }

  if (
    req.method === "POST" &&
    (url.pathname === "/upload" ||
      url.pathname === "/upload/" ||
      url.pathname === "/api/upload" ||
      url.pathname === "/api/upload/")
  ) {
    try {
      const body = await collectRequestBody(req)
      if (isJsonRequest(req)) {
        await handleRemoteUpload(req, res, body)
      } else {
        await handleMultipartUpload(req, res, body)
      }
    } catch (error) {
      respondJson(req, res, error && error.message === "Payload too large" ? 413 : 500, { error: error ? error.message : "Error" })
    }
    return
  }

  if (
    req.method === "POST" &&
    (url.pathname === "/upload-url" ||
      url.pathname === "/upload-url/" ||
      url.pathname === "/api/upload-url" ||
      url.pathname === "/api/upload-url/" ||
      url.pathname === "/upload_url" ||
      url.pathname === "/upload_url/" ||
      url.pathname === "/api/upload_url" ||
      url.pathname === "/api/upload_url/" ||
      url.pathname === "/uploadUrl" ||
      url.pathname === "/uploadUrl/" ||
      url.pathname === "/api/uploadUrl" ||
      url.pathname === "/api/uploadUrl/")
  ) {
    try {
      const body = await collectRequestBody(req)
      await handleRemoteUpload(req, res, body)
    } catch (error) {
      respondJson(req, res, error && error.message === "Payload too large" ? 413 : 500, { error: error ? error.message : "Error" })
    }
    return
  }

  if (req.method === "GET" && url.pathname === "/health") {
    respondJson(req, res, 200, { ok: true })
    return
  }

  if (req.method === "GET" && url.pathname === "/stats") {
    respondJson(req, res, 200, { totalUploads: metadata.totalUploads })
    return
  }

  respondText(req, res, 404, "Not found")
})

ensureUploadDir()
  .then(() => loadMetadata())
  .then(() => {
    server.listen(PORT, HOST, () => {
      console.log(`Files Adonix CDN listening on http://${HOST}:${PORT}`)
    })
  })
  .catch((e) => {
    console.error("Startup error", e)
    process.exit(1)
  })
