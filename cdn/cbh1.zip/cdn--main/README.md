# Files Adonix CDN

CDN sencillo con frontend moderno y backend Node.js para subir archivos, detectar su tipo y servirlos con URLs limpias.

## Inicio rápido

```bash
npm start
```

Abrir `http://localhost:3000`.

## Almacenamiento en GitHub (proxy oculto)

Para subir los archivos al repo `adonix063/files` sin exponer URLs reales de GitHub, configura variables de entorno y usa siempre las rutas del CDN (`/dl/...`).

```bash
GITHUB_TOKEN=tu_token \
GITHUB_REPO=adonix063/files \
GITHUB_BRANCH=main \
GITHUB_UPLOAD_PREFIX=cdn \
EXPIRE_GITHUB_TOKEN=tu_token \
EXPIRE_GITHUB_REPO=adonix063/expire \
EXPIRE_GITHUB_BRANCH=main \
EXPIRE_GITHUB_PATH=expiry.json \
npm start
```

Con esto, el backend sube/lee archivos vía API de GitHub y responde únicamente URLs del dominio del CDN.
Además guarda/carga la expiración (`expiresAt`) en un JSON dentro del repo `adonix063/expire` para recordar la duración aunque reinicie el servidor.

## API

### Subida multipart (form-data)

**Endpoint:** `POST /upload`

**Campos:**
- `files` (file, múltiple): archivos a subir.
- `expiresIn` (string, opcional): `10m`, `1h`, `1d`, `1w`, `never`.

**Ejemplo curl**

```bash
curl -F "files=@/ruta/archivo.pdf" -F "expiresIn=1d" http://localhost:3000/upload
```

**Respuesta**

```json
{
  "files": [
    {
      "originalName": "archivo.pdf",
      "storedName": "hg5.pdf",
      "size": 12345,
      "detected": "pdf",
      "url": "/dl/hg5.pdf",
      "publicUrl": "https://dominiocdn.com/dl/hg5.pdf",
      "expiresAt": 1712345678901
    }
  ]
}
```

### Descarga

**Endpoint:** `GET /dl/:archivo`

El CDN responde con URLs del estilo:

```
https://dominiocdn.com/dl/hg5.pdf
```

Si el archivo venció, la descarga responde `410 Gone`.

### Estadísticas

**Endpoint:** `GET /stats`

Devuelve el total global de subidas:

```json
{
  "totalUploads": 42
}
```
